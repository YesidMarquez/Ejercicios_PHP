<!DOCTYPE html>
<html>
<head>
	<title> </title>
</head>
<body>
<label>Guardar archivos te texto</label><br /><br />
<form action = "guardar.php" method="post" name "frm">

	<label>Nombres </label><br />
	<input type="text" name="nombre"/><br /><br />
	<label>Comentarios</label><br />
	<textarea name="comentario"></textarea><br />
	<input type="submit" value="Guardar los Datos"/><br /><br />

</form>
</body>
</html>