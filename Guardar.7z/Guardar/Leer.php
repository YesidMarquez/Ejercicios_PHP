<?php 

$archivo=fopen("Archivo.txt", "r")
or die ("Problemas al abrir el archivo.txt");

	while (!feof($archivo)) 
	#feof induca cuando el archivi llega al final del texto
	{
		$traer = fgets ($archivo); # fgets obtiene lo que hay en archivo...
		$saltodeinea = nl2br($traer);
		echo $saltodeinea;
	}

 ?>