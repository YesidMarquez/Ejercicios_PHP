<?php 

$fi = fopen("Archivo.txt", "a")
or die("Problemas al crear archivos");

fwrite($fi, "Datos Persobales: ");#fwrite inserta datos en el archivo en forma binaria.
fwrite($fi, "\n"); # "\ n" saltos de linea en archivos de texto
fwrite($fi, $_POST['nombre']);
fwrite($fi, "\n");
fwrite($fi, $_POST['comentario']);
fwrite($fi, "\n");
fwrite($fi, "____________________________________\n");
fclose($fi);
echo "Datos Guardados";


 ?>