<?php  

$operacion = $_POST['lista'];

if (isset($_POST['numero1']) && !empty($_POST['numero1']) &&
   isset($_POST['numero2']) && !empty($_POST['numero2']) &&
   isset($_POST['numero3']) && !empty($_POST['numero3']))
	
{
	echo "El resultado es: ";
switch ($operacion) 
{

	case sumar:
	echo $_POST['numero1'] + $_POST['numero2'] + $_POST['numero3'];
	break;

	case restar:
	echo $_POST['numero1'] - $_POST['numero2'] - $_POST['numero3'];
	break;
	case multiplicar:
	echo $_POST['numero1'] * $_POST['numero2'] * $_POST['numero3'];
	break;
	case dividir:
	echo $_POST['numero1'] / $_POST['numero2'] / $_POST['numero3'];
	break;
	
	default:"no se ha podido realizar la operacion";
}
}else{
	echo "debes insertar todos los campos";
}
?>