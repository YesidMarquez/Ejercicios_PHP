
<?php 

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$pw = $_POST['pw'];
	echo $nombre."<br>";
	echo $apellido."<br>";
	echo $pw;
?>
