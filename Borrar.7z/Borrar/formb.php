<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="borrar.php" method="post" name="form">
	<input type="file" name="archivo" />
	<input type="submit" value="borrar"/>
	
</form>
</body>
</html>