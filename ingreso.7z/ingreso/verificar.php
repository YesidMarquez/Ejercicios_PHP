<?php 
include("conexion.php");
if (isset($_POST['user']) && !empty($_POST['user']) &&
   isset($_POST['pw']) && !empty($_POST['pw']) 
   )
{
	$con=mysql_connect($host,$user,$pw) 
	or die ("Problemas al conectar");#me conecta con la base de datos mysql 

	mysql_select_db($db,$con) or die ("Problemas al conectar la bd");
	$sel=mysql_query("SELECT USUARIO,PW FROM registro WHERE USUARIO = '$_POST[user]'", $con); # and PW = $_POST[PW]
	$sesion=mysql_fetch_array($sel);
if ($_POST['pw'] == $sesion['PW']) {

	$_SESSION['username'] = $_POST['user'];
	echo "Sesion exitosa";

}else{
	echo "Usuario o Contraseña errados";

}

	
}else{
	echo "Se dene llenar ambos campos";
}
?>