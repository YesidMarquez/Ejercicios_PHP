<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="verificar.php" method="post">
	<input type="text" name="user"><br><br>
	<input type="password" name="pw"><br><br>
	<input type="submit" values="Ingresar">

</form >

</body>
</html>