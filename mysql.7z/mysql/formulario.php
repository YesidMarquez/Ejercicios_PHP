<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="insertar.php" method="post" name="formulario">
	<label>Nombres y Apellidos</label><br>
	<input type="text" name="nombre"><br><br>
	<label>Inserte su Contraseña</label><br>
	<input type="password" name="pw"><br><br>
	<input type="submit" value="Insertar"><br><br>
	
</form >

</body>
</html>