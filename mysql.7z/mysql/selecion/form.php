<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="selec.php" method="post" name="form">
	<input type="text" name="nombre"><br>
	<input type="submit" name="Seleccionar">
	
</form>
</body>
</html>