<?php 
include("conex.php");
$con=mysql_connect($host,$user,$pw) 
or die("Error en la conexion server");
mysql_select_db($db,$con)
or die("Error en la conexion db");

$registro=mysql_query("SELECT * FROM personalf WHERE NOMBRE= '$_POST[nombre]'")
or die("Error en consulta:".mysql_error());

while ( $reg= mysql_fetch_array($registro)) {
	echo $reg['NOMBRE']."<br>";
	echo $reg['PW']."<br>"."<br>";
	# code...
}
?>