<?php 

$host = "localhost" ;
$user = "root";
$pw = "LEANDRO6244";
$db = "PLANTA";

?>