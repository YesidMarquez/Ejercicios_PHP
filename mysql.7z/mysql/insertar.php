<?php
include("conex.php");
if (isset($_POST['nombre']) && !empty($_POST['nombre']) &&
	isset($_POST['pw']) && !empty($_POST['pw'])) #VERIFICA QUE SE HALLAN LLENADO LOS FORMULARION

	 {
	$con=mysql_connect($host,$user,$pw) or die ("Problemas al conectar");#me conecta con la base de datos mysql 

	mysql_select_db($db,$con) or die ("Problemas al conectar la bd");
	mysql_query("INSERT INTO personalf (NOMBRE,PW) VALUES ('$_POST[nombre]','$_POST[pw]')", $con);
	echo "Datos insertados";

}else{
	echo "Problemas al insertar datos";
}
?>