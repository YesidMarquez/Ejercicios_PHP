<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="borrar.php" method="post" name="form">
	<input type="text" name="nombre">
	<input type="submit" value="Borrar">
	
</form >

</body>
</html>