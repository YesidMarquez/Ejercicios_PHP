<?php 
include("conexion.php");
$con=mysql_connect($host,$user,$pw) 
or die("Error en la conexion server");
mysql_select_db($db,$con)
or die("Error en la conexion db");

$registro=mysql_query("DELETE FROM personalf WHERE NOMBRE= '$_POST[nombre]'")
or die("Error en consulta:".mysql_error());
echo "Regisdtro eliminado";

#while ( $reg= mysql_fetch_array($registro)) {
#	echo $reg['NOMBRE']."<br>";
#	echo $reg['PW']."<br>"."<br>";
#	# code...
#}
?>