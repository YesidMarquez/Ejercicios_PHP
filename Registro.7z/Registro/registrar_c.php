<?php 
include("conexion.php");
if (isset($_POST['nombre']) && !empty($_POST['nombre']) &&
   isset($_POST['user']) && !empty($_POST['user']) &&
   isset($_POST['pw']) && !empty($_POST['pw']) &&
   isset($_POST['pw2']) && !empty($_POST['pw2']) &&
   isset($_POST['email']) && !empty($_POST['email']) &&
	$_POST['pw']==$_POST['pw2'])
{
	$con=mysql_connect($host,$user,$pw) 
	or die ("Problemas al conectar");#me conecta con la base de datos mysql 

	mysql_select_db($db,$con) or die ("Problemas al conectar la bd");
	mysql_query("INSERT INTO registro (NOMBRE,USUARIO,PW,EMAIL) VALUES ('$_POST[nombre]','$_POST[user]','$_POST[pw]','$_POST[email]')", $con);
	echo "Datos insertados"."<br>";
	echo "Nombre: ".$_POST[nombre]."<br>";
	echo "Usuario: ".$_POST[user]."<br>";
	echo "Password: ".$_POST[pw]."<br>";
	echo "E-mail: ".$_POST[email]."<br>";

}else{
	echo "Problemas al insertar datos, contraseña co noincide";
}
?>