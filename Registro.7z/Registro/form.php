<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="registrar_c.php" method="post" name="form">
<table width="200" border="0">
	<tr>
		<td>NOMBRE:</td>
		<td><input type="text" name="nombre"></td>
	</tr>
	<tr>
		<td>USUARIO:</td>
		<td><input type="text" name="user"></td>		
	</tr>
	<tr>
		<td>PASSWORD:</td>
		<td><input type="PASSWORD" name="pw"></td>		
	</tr>
	<tr>
		<td>CONFIRMAR PASSWORD:</td>
		<td><input type="PASSWORD" name="pw2"></td>		
	</tr>
	<tr>
		<td>CORREO</td>
		<td><input type="text" name="email"></td>		
	</tr>
	
	<tr>
		<td></td>
		<td><input type="submit" value="Registrar"></td>
	</tr>
	
</table>
	
	
	
</form >

</body>
</html>